{:namespaces
 ({:source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ezprotoflex.examples.csv_parse-api.html",
   :name "protoflex.examples.csv_parse",
   :doc nil}
  {:source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ezprotoflex.examples.xml_parse-api.html",
   :name "protoflex.examples.xml_parse",
   :doc nil}
  {:source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ezprotoflex.parse-api.html",
   :name "protoflex.parse",
   :author "Panduranga Adusumilli",
   :doc "Clojure Parser Library."}
  {:source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ezprotoflex.util-api.html",
   :name "protoflex.util",
   :doc "Misc Utilities."}),
 :vars
 ({:arglists ([] [sep]),
   :name "csv",
   :namespace "protoflex.examples.csv_parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.examples.csv_parse-api.html#protoflex.examples.csv_parse/csv",
   :doc
   "Reads and returns one or more records as a vector of vector of field-values",
   :var-type "function",
   :line 6,
   :file "src/protoflex/examples/csv_parse.clj"}
  {:arglists ([sep]),
   :name "csv-1",
   :namespace "protoflex.examples.csv_parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.examples.csv_parse-api.html#protoflex.examples.csv_parse/csv-1",
   :doc "Reads and returns the fields of one record (line)",
   :var-type "function",
   :line 11,
   :file "src/protoflex/examples/csv_parse.clj"}
  {:arglists ([]),
   :name "detect-sep",
   :namespace "protoflex.examples.csv_parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.examples.csv_parse-api.html#protoflex.examples.csv_parse/detect-sep",
   :doc "Detects the separator used in a csv file (a comma or a tab)",
   :var-type "function",
   :line 15,
   :file "src/protoflex/examples/csv_parse.clj"}
  {:arglists ([parse-fn]),
   :name "ang-brackets",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/ang-brackets",
   :doc
   "Returns the result of applying specifed parse function to text that is\nin between the opening and closing angular brackets '<' and '>'",
   :var-type "function",
   :line 390,
   :file "src/protoflex/parse.clj"}
  {:arglists ([& parse-fns]),
   :name "any",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/any",
   :doc
   "Returns the result of the first successfully matching parse-function.\nIf none of the parse functions match, an exception is thrown.",
   :var-type "function",
   :line 105,
   :file "src/protoflex/parse.clj"}
  {:arglists ([sep]),
   :name "any-string",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/any-string",
   :doc
   "Reads a single-quoted or double-quoted or a plain-string that is followed\nby the specified separator sep; the separator is not part of the returned\nstring.",
   :var-type "function",
   :line 359,
   :file "src/protoflex/parse.clj"}
  {:arglists ([& parse-exprs]),
   :name "any_",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/any_",
   :doc
   "Creates and returns a parse function that calls `any` when it is\ninvoked. The arguments `parse-exprs` are converted to parse functions\nand passed to `any` in the returned function's body.  See `any`.",
   :var-type "macro",
   :line 116,
   :file "src/protoflex/parse.clj"}
  {:arglists ([]),
   :name "at-end?",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/at-end?",
   :doc
   "Returns true if no more input is left to be read; false otherwise.",
   :var-type "function",
   :line 589,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-fn]),
   :name "attempt",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/attempt",
   :doc
   "Tries to match the input at the current position with the provided\nparse function. If the parse function matches successfully, the matched\ntext is returned and the input cursor advances by the length of the\nmatched text. Otherwise a nil is returned and the current position\nin the input remains unchanged.",
   :var-type "function",
   :line 74,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-expr]),
   :name "attempt_",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/attempt_",
   :doc
   "Creates and returns a parse function that calls `attempt` when it is\ninvoked. The argument `parse-expr` is converted to a parse function\nand passed to `attempt` in the returned function's body.  See `attempt`.",
   :var-type "macro",
   :line 85,
   :file "src/protoflex/parse.clj"}
  {:arglists ([]),
   :name "auto-trim-if",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/auto-trim-if",
   :doc
   "Automatically trim the leading input text if :auto-trim option is set to true.",
   :var-type "function",
   :line 766,
   :file "src/protoflex/parse.clj"}
  {:arglists ([]),
   :name "auto-trim-off",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/auto-trim-off",
   :doc "Turns off the auto-trim option.",
   :var-type "function",
   :line 646,
   :file "src/protoflex/parse.clj"}
  {:arglists ([]),
   :name "auto-trim-on",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/auto-trim-on",
   :doc
   "Turns on auto-trim feature that cleans trailing white-space, comments\nor whatever the custom ws-reader if any is spe",
   :var-type "function",
   :line 640,
   :file "src/protoflex/parse.clj"}
  {:arglists ([mark]),
   :name "back-to-mark",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/back-to-mark",
   :doc "Resets the positional parameters to a previously set mark.",
   :var-type "function",
   :line 692,
   :file "src/protoflex/parse.clj"}
  {:arglists ([start-fn parse-fn end-fn]),
   :name "between",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/between",
   :doc
   "Applies the supplied start-fn, parse-fn and end-fn functions and returns\nthe result of parse-fn. This is typically used to parse content enclosed by\nsome delimiters on either side.",
   :var-type "function",
   :line 368,
   :file "src/protoflex/parse.clj"}
  {:arglists ([beg end]),
   :name "blk-cmt",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/blk-cmt",
   :doc
   "Reads and returns a block comment as specified by the begin and end\nmarkers.  Throws an exception if the specified block-comment doesn't\noccur at the current position.",
   :var-type "function",
   :line 533,
   :file "src/protoflex/parse.clj"}
  {:arglists ([beg end]),
   :name "blk-cmt?",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/blk-cmt?",
   :doc
   "Similar to blk-cmt but returns a nil instead of throwing an exception\nin case of a match failure.",
   :var-type "function",
   :line 541,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-fn]),
   :name "braces",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/braces",
   :doc
   "Returns the result of applying specifed parse function to text that is\nin between the opening and closing braces '{' and '}'",
   :var-type "function",
   :line 380,
   :file "src/protoflex/parse.clj"}
  {:arglists ([ch]),
   :name "chr",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/chr",
   :doc
   "If the next character in the input matches the specified character ch,\nreturns it; otherwise throws an exception.",
   :var-type "function",
   :line 286,
   :file "src/protoflex/parse.clj"}
  {:arglists ([ch]),
   :name "chr-",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/chr-",
   :doc
   "Same as chr but with auto-trimming turned off for the following input",
   :var-type "function",
   :line 291,
   :file "src/protoflex/parse.clj"}
  {:arglists ([chars]),
   :name "chr-in",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/chr-in",
   :doc
   "If the next character in the input matches any character in the specified\nstring or character collection, the matching character is returned.\nOtherwise throws an exception.",
   :var-type "function",
   :line 295,
   :file "src/protoflex/parse.clj"}
  {:arglists ([chars]),
   :name "chr-in-",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/chr-in-",
   :doc
   "Same as chr-in but with auto-trimming turned off for the following input",
   :var-type "function",
   :line 301,
   :file "src/protoflex/parse.clj"}
  {:arglists ([]),
   :name "decimal",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/decimal",
   :doc "Parses a decimal value and returns a Double.",
   :var-type "function",
   :line 406,
   :file "src/protoflex/parse.clj"}
  {:arglists ([]),
   :name "dq-str",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/dq-str",
   :doc
   "Parses a double-quoted string and returns the matched string (minus the quotes)",
   :var-type "function",
   :line 421,
   :file "src/protoflex/parse.clj"}
  {:arglists ([& args]),
   :name "eval-expr",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/eval-expr",
   :doc
   "Parses and evaluates an expression in infix notation.\nArgs: expression-string followed by parser options.  See parse function for details.",
   :var-type "function",
   :line 916,
   :file "src/protoflex/parse.clj"}
  {:arglists ([ptree]),
   :name "eval-expr-tree",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/eval-expr-tree",
   :doc "Evaluates the parse tree returned by expr parse function.",
   :var-type "function",
   :line 906,
   :file "src/protoflex/parse.clj"}
  {:arglists ([expected-msg parse-fn]),
   :name "expect",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/expect",
   :doc
   "Customize error message; if the specified parse function doesn't match\nthe current input text, the error message of the parse exception will include\nthe specified custom expected-message.",
   :var-type "function",
   :line 250,
   :file "src/protoflex/parse.clj"}
  {:arglists ([expected-msg parse-expr]),
   :name "expect_",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/expect_",
   :doc
   "Creates and returns a parse function that calls `expect` when it is\ninvoked. The argument `parse-expr` is converted to a parse function\nand passed to `expect` in the returned function's body.  See `expect`.",
   :var-type "macro",
   :line 261,
   :file "src/protoflex/parse.clj"}
  {:arglists ([]),
   :name "expr",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/expr",
   :doc
   "Parses expressions and returns the parse tree as nested vectors.",
   :var-type "function",
   :line 878,
   :file "src/protoflex/parse.clj"}
  {:arglists ([k] [k d]),
   :name "get-opt",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/get-opt",
   :doc
   "Returns the value for parser option k; if the optional default value\nparameter d is specified, its value is returned if the option k is not set\nin parser options.",
   :var-type "function",
   :line 633,
   :file "src/protoflex/parse.clj"}
  {:arglists ([]),
   :name "integer",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/integer",
   :doc "Parses a long integer value and returns a Long.",
   :var-type "function",
   :line 402,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-fn]),
   :name "lexeme",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/lexeme",
   :doc
   "Applies the specified parse function for current input text, consumes any\nfollowing whitespace, comments and returns the result of the parse function\napplication.",
   :var-type "function",
   :line 225,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-expr]),
   :name "lexeme_",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/lexeme_",
   :doc
   "Creates and returns a parse function that calls `lexeme` when it is\ninvoked. The argument `parse-expr` is converted to a parse function\nand passed to `lexeme` in the returned function's body.  See `lexeme`.",
   :var-type "macro",
   :line 232,
   :file "src/protoflex/parse.clj"}
  {:arglists ([beg]),
   :name "line-cmt",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/line-cmt",
   :doc
   "Reads and returns a line comment as specified by the begin marker.\nThrows an exception if the specified block-comment doesn't occur at the\ncurrent position.",
   :var-type "function",
   :line 550,
   :file "src/protoflex/parse.clj"}
  {:arglists ([beg]),
   :name "line-cmt?",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/line-cmt?",
   :doc
   "Similar to line-cmt but returns a nil instead of throwing an exception\nin case of a match failure.",
   :var-type "function",
   :line 560,
   :file "src/protoflex/parse.clj"}
  {:arglists ([]),
   :name "line-pos",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/line-pos",
   :doc
   "Returns [line column] vector representing the current cursor position\nof the parser",
   :var-type "function",
   :line 593,
   :file "src/protoflex/parse.clj"}
  {:arglists ([]),
   :name "line-pos-str",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/line-pos-str",
   :doc "Returns line position in a descriptive string.",
   :var-type "function",
   :line 603,
   :file "src/protoflex/parse.clj"}
  {:arglists ([la-pf-vec]),
   :name "look-ahead",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/look-ahead",
   :doc
   "Takes a collection of look-ahead-string and parse-function pairs and applies\nthe first parse function that follows the matching look-ahead-string  and\nreturns the result, or throws a parse exception if the parse function fails.\n\nIf none of the look-ahead strings match the current text, an exception is thrown.\n\nTo specify a default parse function, provide an empty string as look-ahead and\nthe default parse function at the end of the argument list.\n\nArgs: [la-str-1 parse-fn-1 la-str-2 parse-fn-2 ...]",
   :var-type "function",
   :line 133,
   :file "src/protoflex/parse.clj"}
  {:arglists ([la-pf-vec]),
   :name "look-ahead*",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/look-ahead*",
   :doc
   "Same as look-ahead, but consumes the matching look-ahead string before\napplying the corresponding parse function. ",
   :var-type "function",
   :line 153,
   :file "src/protoflex/parse.clj"}
  {:arglists ([]),
   :name "mark-pos",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/mark-pos",
   :doc "Returns the current positional parameters of the parser.",
   :var-type "function",
   :line 688,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-fn]),
   :name "multi*",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/multi*",
   :doc
   "Matches zero or more occurrences of text accepted by the provided parse \nfunction and returns the results in a vector.",
   :var-type "function",
   :line 182,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-expr]),
   :name "multi*_",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/multi*_",
   :doc
   "Creates and returns a parse function that calls `multi*` when it is\ninvoked. The argument `parse-expr` is converted to a parse function\nand passed to `multi*` in the returned function's body.  See `multi*`.",
   :var-type "macro",
   :line 191,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-fn]),
   :name "multi+",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/multi+",
   :doc
   "Matches one or more occurrences of text accepted by the provided parse \nfunction and returns the results in a vector. If the parse function doesn't \nmatch even once, an exception is thrown.",
   :var-type "function",
   :line 198,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-expr]),
   :name "multi+_",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/multi+_",
   :doc
   "Creates and returns a parse function that calls `multi+` when it is\ninvoked. The argument `parse-expr` is converted to a parse function\nand passed to `multi+` in the returned function's body.  See `multi+`.",
   :var-type "macro",
   :line 205,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-fn]),
   :name "no-trim",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/no-trim",
   :doc
   "Similar to with-trim-off, but takes a function as a parameter instead of\nthe body",
   :var-type "function",
   :line 726,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-fn]),
   :name "no-trim-nl",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/no-trim-nl",
   :doc
   "Turns off automatic trimming of newline characters (as part of white-space)\nand executes the specified function. The earlier auto-trim options are restored\nat the end of execution of the specified function.",
   :var-type "function",
   :line 739,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-expr]),
   :name "no-trim-nl_",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/no-trim-nl_",
   :doc
   "Creates and returns a parse function that calls `no-trim-nl` when it is\ninvoked. The argument `parse-expr` is converted to a parse function\nand passed to `no-trim-nl` in the returned function's body.  See `no-trim-nl`.",
   :var-type "macro",
   :line 749,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-expr]),
   :name "no-trim_",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/no-trim_",
   :doc
   "Creates and returns a parse function that calls `no-trim` when it is\ninvoked. The argument `parse-expr` is converted to a parse function\nand passed to `no-trim` in the returned function's body.  See `no-trim`.",
   :var-type "macro",
   :line 731,
   :file "src/protoflex/parse.clj"}
  {:arglists ([]),
   :name "number",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/number",
   :doc
   "Matches an integral or non-integral numeric value. While the function \ndecimal also matches both integer and non-integer values, it always\nreturns a Double; where as number returns Long for integers and Double\nfor non-integers.",
   :var-type "function",
   :line 410,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-fn] [parse-fn default-val]),
   :name "opt",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/opt",
   :doc
   "Same as attempt, but accepts a default value argument to return in case the\nspecified parse function fails.  Useful for matching optional text.",
   :var-type "function",
   :line 92,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-expr] [parse-expr default-val]),
   :name "opt_",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/opt_",
   :doc
   "Creates and returns a parse function that calls `opt` when it is\ninvoked. The argument `parse-expr` is converted to a parse function\nand passed to `opt` in the returned function's body.  See `opt`.",
   :var-type "macro",
   :line 98,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-fn]),
   :name "parens",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/parens",
   :doc
   "Returns the result of applying specifed parse function to text that is\nin between the opening and closing parentheses '(' and ')'",
   :var-type "function",
   :line 375,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-fn input-str & opts]),
   :name "parse",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/parse",
   :doc
   "This function triggers off the parsing of the provided input string using\nthe specified parse function. The following parser options may be provided \nto alter the default behavior of the parser:\n:blk-cmt-delim - vector specifying start and end of block-comment markers\n:line-cmt-start - string specifying the begin marker of a line comment\n:ws-regex - regular expression for matching (non-comment) white space\n:auto-trim - whether to automatically remove the leading whitespace/comments\nat the current position in the input text or immediately after a parse action.\n:word-regex - regular expression for matching words\n:operators - a vector of vector of operators in the decreasing order of\nprecedence; see get-default-ops function for an example.\n:op-fn-map - a map of operator and the function to call for that operator when\nevaluating expressions\n:eof - if true, the parse function must consume the entire input text\n\nArgs:\nparse-fn  - parse function to apply\ninput-str - input text to be parsed\nopts      - key value options (listed above)",
   :var-type "function",
   :line 35,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-expr input-str & opts]),
   :name "parse_",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/parse_",
   :doc
   "Similar to the `parse` function, but takes a parse expression instead of a\nparse function as its first argument. The parse expression is any clojure\nexpression that performs parsing by calling built-in or custom parse\nfunctions. See the documentation for `parse`",
   :var-type "macro",
   :line 65,
   :file "src/protoflex/parse.clj"}
  {:arglists ([input-str] [input-str opts]),
   :name "parser-init",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/parser-init",
   :doc
   "Initializes the parser state with the specified input string and options.",
   :var-type "function",
   :line 609,
   :file "src/protoflex/parse.clj"}
  {:arglists ([] [is-no-auto-trim]),
   :name "read-ch",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/read-ch",
   :doc
   "Reads and return the next input character. Throws an exception if the\ncurrent position is at the end of the input.",
   :var-type "function",
   :line 512,
   :file "src/protoflex/parse.clj"}
  {:arglists ([char-set] [char-set is-no-auto-trim]),
   :name "read-ch-in-set",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/read-ch-in-set",
   :doc
   "Reads and returns the next character if it matches any of the characters\nspecified in the provided set.  An exception is thrown otherwise.  The\noptional is-no-auto-trim argument may be used to specify whether or not\nto apply auto-trim after reading the next character.",
   :var-type "function",
   :line 522,
   :file "src/protoflex/parse.clj"}
  {:arglists ([n]),
   :name "read-n",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/read-n",
   :doc
   "Reads and returns an n-character string at the current position.",
   :var-type "function",
   :line 504,
   :file "src/protoflex/parse.clj"}
  {:arglists ([re] [re grp]),
   :name "read-re",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/read-re",
   :doc
   "Reads the string matching the specified regular expression. If a match-group\nis specified, the corresponding text is returned; otherwise the entire \nmatched text is returned.",
   :var-type "function",
   :line 460,
   :file "src/protoflex/parse.clj"}
  {:arglists ([s]),
   :name "read-to",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/read-to",
   :doc
   "The parser skips to the position where the text contains the string\nspecified by s. The string itself is not consumed, that is the cursor is\npositioned at the beginning of the match. If the specified string is not\nfound, cursor position does not change and a parse exception is thrown.",
   :var-type "function",
   :line 440,
   :file "src/protoflex/parse.clj"}
  {:arglists ([re]),
   :name "read-to-re",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/read-to-re",
   :doc
   "Reads and returns text upto but not including the text matched by the\nspecified regular expression. If the specified regular expression doesn't\noccur in the remaining input text, an exception is thrown.",
   :var-type "function",
   :line 473,
   :file "src/protoflex/parse.clj"}
  {:arglists ([]),
   :name "read-ws",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/read-ws",
   :doc
   "Reads whitespace (including comments) using a whitespace reader based\non parser options. If the :ws-reader option is not set, a default whitespace\nreader based on other parser options such as :ws-regex, :blk-cmt-delim and\n:line-cmt-start will be used. Returns the whitespace read.",
   :var-type "function",
   :line 757,
   :file "src/protoflex/parse.clj"}
  {:arglists ([re] [re grp]),
   :name "regex",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/regex",
   :doc
   "Returns the text matched by the specified regex; If a group is specified,\nthe returned text is for that group only. In either case, the cursor is\nadvanced by the length of the entire matched text (group 0)",
   :var-type "function",
   :line 395,
   :file "src/protoflex/parse.clj"}
  {:arglists ([fld-fn fld-sep-fn] [fld-fn fld-sep-fn rec-sep-fn]),
   :name "sep-by",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/sep-by",
   :doc
   "Reads a record using the specified field, field-separator and \nrecord-separator parse functions.  If no record-separator is specified, \na newline character is used as record separator. Returns the fields of the \nrecord in a vector.",
   :var-type "function",
   :line 342,
   :file "src/protoflex/parse.clj"}
  {:arglists ([& parse-fns]),
   :name "series",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/series",
   :doc
   "Applies a sequence of parse functions and returns their results in\na vector. Each successfull match by the parse function advances the cursor.\nIf any of the parse functions fails, an exception is thrown.",
   :var-type "function",
   :line 159,
   :file "src/protoflex/parse.clj"}
  {:arglists ([& parse-exprs]),
   :name "series_",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/series_",
   :doc
   "Creates and returns a parse function that calls `series` when it is\ninvoked. The arguments `parse-exprs` are converted to parse functions\nand passed to `series` in the returned function's body.  See `series`.",
   :var-type "macro",
   :line 175,
   :file "src/protoflex/parse.clj"}
  {:arglists ([beg end]),
   :name "set-blk-cmt-opts",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/set-blk-cmt-opts",
   :doc "Sets block comment begin and end markers.",
   :var-type "function",
   :line 650,
   :file "src/protoflex/parse.clj"}
  {:arglists ([beg]),
   :name "set-line-cmt-opts",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/set-line-cmt-opts",
   :doc "Sets line comment begin marker.",
   :var-type "function",
   :line 655,
   :file "src/protoflex/parse.clj"}
  {:arglists ([k v]),
   :name "set-opt",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/set-opt",
   :doc "Sets parser option k to value v",
   :var-type "function",
   :line 626,
   :file "src/protoflex/parse.clj"}
  {:arglists ([ws-reader]),
   :name "set-ws-reader",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/set-ws-reader",
   :doc
   "This sets the white-space parser to be used when auto-trim is set.\nIf this is specified, it overrides the options set by set-blk-cmt-opts,\nset-line-cmt-opts and set-ws-regex options.",
   :var-type "function",
   :line 665,
   :file "src/protoflex/parse.clj"}
  {:arglists ([ws-re]),
   :name "set-ws-regex",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/set-ws-regex",
   :doc
   "Sets the regular expression to be used for matching non-comment white-space.",
   :var-type "function",
   :line 660,
   :file "src/protoflex/parse.clj"}
  {:arglists ([s]),
   :name "skip-over",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/skip-over",
   :doc
   "Finds the specified string s in the input and skips over it. If the string\nis not found, a parse exception is thrown.",
   :var-type "function",
   :line 450,
   :file "src/protoflex/parse.clj"}
  {:arglists ([re]),
   :name "skip-over-re",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/skip-over-re",
   :doc
   "Reads and returns text upto and including the text matched by the\nspecified regular expression. If the specified regular expression doesn't\noccur in the remaining input text, an exception is thrown.",
   :var-type "function",
   :line 486,
   :file "src/protoflex/parse.clj"}
  {:arglists ([parse-fn]),
   :name "sq-brackets",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/sq-brackets",
   :doc
   "Returns the result of applying specifed parse function to text that is\nin between the opening and closing square brackets '[' and ']'",
   :var-type "function",
   :line 385,
   :file "src/protoflex/parse.clj"}
  {:arglists ([]),
   :name "sq-str",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/sq-str",
   :doc
   "Parses a single-quoted string and returns the matched string (minus the quotes)",
   :var-type "function",
   :line 417,
   :file "src/protoflex/parse.clj"}
  {:arglists ([re]),
   :name "starts-with-re?",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/starts-with-re?",
   :doc
   "Returns a boolean value indicating whether the specified regular expression\nmatches the input at the current position.",
   :var-type "function",
   :line 499,
   :file "src/protoflex/parse.clj"}
  {:arglists ([s]),
   :name "starts-with?",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/starts-with?",
   :doc
   "Returns a boolean value indicating whether the current input text matches\nthe specified string.",
   :var-type "function",
   :line 494,
   :file "src/protoflex/parse.clj"}
  {:arglists ([s]),
   :name "string",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/string",
   :doc
   "If the input matches the specified string, the string is\nreturned. Otherwise, a parse exception is thrown.",
   :var-type "function",
   :line 305,
   :file "src/protoflex/parse.clj"}
  {:arglists ([strings]),
   :name "string-in",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/string-in",
   :doc
   "Returns the longest string from the provided strings that matches text\nat the current position. Throws an exception if none of the strings match.",
   :var-type "function",
   :line 320,
   :file "src/protoflex/parse.clj"}
  {:arglists ([strings]),
   :name "string-in-ord",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/string-in-ord",
   :doc
   "Returns the first string from the provided strings that matches text\nat the current position. Throws an exception if none of the strings match.",
   :var-type "function",
   :line 312,
   :file "src/protoflex/parse.clj"}
  {:arglists ([] [msg]),
   :name "throw-ex",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/throw-ex",
   :doc
   "Throws an exception; this is usually called to indicate a match\nfailure in a parse function.",
   :var-type "function",
   :line 268,
   :file "src/protoflex/parse.clj"}
  {:arglists ([n parse-fn]),
   :name "times",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/times",
   :doc
   "Applies the provided parse function exactly n times and returns the\nresults of applications of the function in a vector.",
   :var-type "function",
   :line 212,
   :file "src/protoflex/parse.clj"}
  {:arglists ([n parse-expr]),
   :name "times_",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/times_",
   :doc
   "Creates and returns a parse function that calls `times` when it is\ninvoked. The argument `parse-expr` is converted to a parse function\nand passed to `times` in the returned function's body.  See `times`.",
   :var-type "macro",
   :line 218,
   :file "src/protoflex/parse.clj"}
  {:arglists ([expected] [actual expected]),
   :name "unexpected",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/unexpected",
   :doc "Creates a message string for unexpected input exception.",
   :var-type "function",
   :line 274,
   :file "src/protoflex/parse.clj"}
  {:arglists ([& body]),
   :name "with-trim-off",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/with-trim-off",
   :doc
   "Executes the provided body with auto-trim option set to false.  The earlier\nvalue of the auto-trim option is restored after executing the body.",
   :var-type "macro",
   :line 715,
   :file "src/protoflex/parse.clj"}
  {:arglists ([& body]),
   :name "with-trim-on",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/with-trim-on",
   :doc
   "Executes the provided body with auto-trim option set to true.  The earlier\nvalue of the auto-trim option is restored after executing the body.",
   :var-type "macro",
   :line 704,
   :file "src/protoflex/parse.clj"}
  {:arglists ([w]),
   :name "word",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/word",
   :doc
   "Returns the specified word if the word occurs at the current position in\nthe input text; an exception is thrown otherwise.",
   :var-type "function",
   :line 337,
   :file "src/protoflex/parse.clj"}
  {:arglists ([str-coll] [str-coll word-reader]),
   :name "word-in",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/word-in",
   :doc
   "Returns the first word from the provided words that matches text\nat the current position. Throws an exception if none of the words match.\nAn optional word-reader parse-function may be provided to read words.",
   :var-type "function",
   :line 326,
   :file "src/protoflex/parse.clj"}
  {:arglists ([] [bcb bce lcb wsre]),
   :name "ws",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/ws",
   :doc
   "Matches white space (including comments) at the current position.  The\noptional parameters bcb, bce, lcb and wsre specify block-comment-begin,\nblock-comment-end, line-comment-begin and white-space-regex respectively.\nIf they are not specified here, the options set for the parser are used.\nThrows an exception if white space doesn't occur at the current position.",
   :var-type "function",
   :line 565,
   :file "src/protoflex/parse.clj"}
  {:arglists ([& args]),
   :name "ws?",
   :namespace "protoflex.parse",
   :source-url nil,
   :raw-source-url nil,
   :wiki-url
   "http://www.proroflex.com/parse-ez/protoflex.parse-api.html#protoflex.parse/ws?",
   :doc
   "Similar to ws except that a nil value is returned instead of throwing\nan exception in case of a match failure.",
   :var-type "function",
   :line 584,
   :file "src/protoflex/parse.clj"})}
